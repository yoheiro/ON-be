# on-be

オンライン雑談を実現する在宅休憩スペースモデル「ON-be」

beacon を使ってリモートワークでも実際に休憩スペースに”入る”！！ 自宅にある休憩スペースをオンラインでつなげるサービス。

## Build Setup

```bash
# install dependencies
$ npm install

# serve with hot reload at localhost:3000
$ npm run dev

# build for production and launch server
$ npm run build
$ npm run start

# generate static project
$ npm run generate
```

For detailed explanation on how things work, check out [Nuxt.js docs](https://nuxtjs.org).
